Notes:

1. See [assembly.jpg] file to see how model parts are assembled.

2. Model is designed to fit together without the need for glue, but a small drop at connection points will help to strengthen it.

3. Be sure to print 2 copies of the pins.

